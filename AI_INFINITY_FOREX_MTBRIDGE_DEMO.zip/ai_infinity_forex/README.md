# AI INFINITY FOREX — MT Bridge starter (demo-first)

This is a starter project with an HTML dashboard and FastAPI backend. It uses MT Bridge's documented REST endpoints. It is not deployed or connected until you create MT Bridge credentials and host the backend.

## Important constraints
- MT Bridge requires requests from an IP address on its whitelist. A static outbound IP is recommended for an always-on hosted backend. A free serverless host with changing egress IP may not work.
- Keep `MTBRIDGE_API_KEY` and `APP_TOKEN` on the backend only. Never put them in `frontend/index.html`, GitHub, screenshots, or chat.
- The code blocks trade endpoints until `DEMO_ACCOUNT_CONFIRMED=true`. Only change this after verifying the account in MT Bridge is a JustMarkets DEMO account. The API code cannot independently prove the account is demo.
- The strategy is a simple sampled-price EMA crossover prototype. It is not machine learning, does not read historical candles or a forex news calendar, and is not validated for profitability. Use demo only and monitor it.
- The automatic strategy is configured for a fixed 0.01 lot size and enforces a maximum of 5 strategy-tagged open positions across the account. The dashboard starts in stopped mode; pressing Start enables the strategy loop and it waits for sufficient price samples and a valid EMA crossover before placing an order. Stop prevents new entries but does not close existing positions. The strategy polls sampled prices every 15 seconds. The max spread field is a raw price difference, so tune it to the broker symbol's digits. Default `0.0005` is intended as a conservative EURUSD-style value and may not suit gold.
- Position filtering is strategy-tag based; confirm MT Bridge's returned position schema and test with tiny demo volumes. Do not use live funds.

## 1. Create MT Bridge demo connection
1. Register at https://mtbridge.in/ and verify email.
2. Add your JustMarkets MT5 DEMO account in MT Bridge using login, trading password and exact demo server. Do not share those details with anyone.
3. Copy the account-specific MT Bridge API key.
4. Check MT Bridge supports the exact JustMarkets server and confirm the account is demo.

## 2. Deploy backend on a host with a static outbound IP
Use a Python host that can run a persistent web service and worker, with fixed outbound IP. Add that IP in MT Bridge Settings → IP Whitelist. A generic host with rotating egress IP may fail.

Build/start commands:
```
pip install -r backend/requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```
Run from the `backend` directory. Configure environment variables from `.env.example` in the hosting dashboard. Keep `DEMO_ACCOUNT_CONFIRMED=false` initially. After confirming the account is demo, set it to `true` and restart.

## 3. Host frontend
Host `frontend/index.html` on any static HTTPS host. Set backend `CORS_ORIGINS` to the exact frontend origin. Open the page, enter backend URL and `APP_TOKEN`, then Test MT Bridge.

## 4. Test safely
- First check balance, prices and positions.
- Verify symbol spelling in MT5/JustMarkets (gold may be XAUUSD, XAUUSDm, etc.).
- Use 0.01 demo lots and check MT Bridge logs plus MT5 positions.
- Start the strategy only after you understand its EMA crossover and spread filter. Stop it immediately if behaviour differs from expectation.

## API routes
- `GET /api/health`
- `POST /api/test-connection`
- `GET /api/balance`, `/api/positions`, `/api/prices`
- `POST /api/trade`
- `POST /api/engine/start`, `/api/engine/stop`

The backend has a simple shared app token and should be placed behind HTTPS. For production, add user authentication, encrypted secret storage, rate limiting, persistent audit logs, a proper worker process and server-side verification of account type.
