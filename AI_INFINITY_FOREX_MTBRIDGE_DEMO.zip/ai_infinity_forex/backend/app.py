import os, asyncio, statistics
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from typing import Optional
import httpx
from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()
BRIDGE = "https://webhook.mtbridge.in"
API_KEY = os.getenv("MTBRIDGE_API_KEY", "").strip()
APP_TOKEN = os.getenv("APP_TOKEN", "change-this-long-random-token")
DEMO_CONFIRM = os.getenv("DEMO_ACCOUNT_CONFIRMED", "false").lower() == "true"
SYMBOLS = [s.strip() for s in os.getenv("SYMBOLS", "EURUSD,XAUUSD").split(",") if s.strip()]
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "15"))
STRATEGY_TAG = "AI_INFINITY_FOREX"

engine = {"running": False, "last_signal": "Waiting for market data", "last_error": None, "ticks": defaultdict(lambda: deque(maxlen=100))}

async def bridge(path: str, payload: dict):
    if not API_KEY:
        raise HTTPException(503, "MT Bridge API key is not configured in backend/.env")
    body = {"apikey": API_KEY, **payload}
    try:
        async with httpx.AsyncClient(timeout=25) as client:
            r = await client.post(BRIDGE + path, json=body)
            data = r.json()
            if r.status_code >= 400:
                raise HTTPException(r.status_code, data)
            return data
    except httpx.RequestError as e:
        raise HTTPException(502, f"MT Bridge connection error: {e}")

def auth(x_app_token: Optional[str]):
    if not x_app_token or x_app_token != APP_TOKEN:
        raise HTTPException(401, "Invalid app token")

@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(strategy_loop())
    yield
    task.cancel()

app = FastAPI(title="AI INFINITY FOREX API", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:8080").split(","), allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["Content-Type", "X-App-Token"])

class TradeRequest(BaseModel):
    symbol: str = Field(min_length=3, max_length=20)
    action: str
    quantity: float = Field(default=0.01, gt=0, le=0.01)
    stop_loss: int = Field(default=30, ge=5, le=5000)
    take_profit: int = Field(default=60, ge=5, le=10000)

class EngineRequest(BaseModel):
    symbols: list[str] = Field(default_factory=lambda: SYMBOLS, min_length=1, max_length=5)
    quantity: float = Field(default=0.01, gt=0, le=0.01)
    max_open_trades: int = Field(default=5, ge=1, le=5)
    stop_loss: int = Field(default=30, ge=5, le=5000)
    take_profit: int = Field(default=60, ge=5, le=10000)
    max_spread: float = Field(default=5.0, gt=0)

@app.get('/api/health')
def health():
    return {"ok": True, "service": "AI INFINITY FOREX", "mode": "DEMO-ONLY CONFIGURATION", "bridge_key_configured": bool(API_KEY), "demo_confirmation": DEMO_CONFIRM}

@app.get('/api/status')
def status(x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    return {"running": engine["running"], "last_signal": engine["last_signal"], "last_error": engine["last_error"], "symbols": SYMBOLS, "demo_confirmation": DEMO_CONFIRM}

@app.post('/api/test-connection')
async def test_connection(x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    bal = await bridge('/balance', {})
    return {"connected": bool(bal.get('success', True)), "balance": bal}

@app.get('/api/balance')
async def balance(x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token); return await bridge('/balance', {})

@app.get('/api/positions')
async def positions(x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token); return await bridge('/positions', {})

@app.get('/api/prices')
async def prices(x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token); return await bridge('/get_ltp', {"symbol": ",".join(SYMBOLS)})

@app.post('/api/trade')
async def trade(req: TradeRequest, x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    if not DEMO_CONFIRM: raise HTTPException(403, "Trading locked. Set DEMO_ACCOUNT_CONFIRMED=true only after verifying the connected MT Bridge account is a JustMarkets DEMO account.")
    if req.action not in ('buy','sell'): raise HTTPException(400, "Only buy or sell entries are allowed")
    return await bridge('/', {"symbol": req.symbol, "action": req.action, "quantity": req.quantity, "order_type":"MARKET", "stop_loss":req.stop_loss, "take_profit":req.take_profit, "tpsl_mode":"pips", "strategy_tag":STRATEGY_TAG})

@app.post('/api/engine/start')
def start(req: EngineRequest, x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token)
    if not DEMO_CONFIRM: raise HTTPException(403, "Auto trading locked until demo account is confirmed in backend/.env")
    if any(s.upper() not in [x.upper() for x in SYMBOLS] for s in req.symbols): raise HTTPException(400, "Use only symbols configured in backend/.env")
    engine.update({"running": True, "settings": req.model_dump(), "last_error": None, "last_signal": "Engine started; collecting price samples"})
    return {"running": True, "settings": req}

@app.post('/api/engine/stop')
def stop(x_app_token: Optional[str] = Header(default=None)):
    auth(x_app_token); engine["running"] = False; engine["last_signal"] = "Stopped by user"; return {"running": False}

async def strategy_loop():
    while True:
        await asyncio.sleep(POLL_SECONDS)
        if not engine["running"] or not API_KEY: continue
        try:
            settings = engine.get("settings", {})
            syms = settings.get("symbols", SYMBOLS)
            q = await bridge('/get_ltp', {"symbol": ",".join(syms)})
            rows = q.get('prices', q.get('data', q if isinstance(q, list) else []))
            if isinstance(rows, dict): rows = [dict(v, symbol=k) if isinstance(v,dict) else v for k,v in rows.items()]
            for row in rows:
                if not isinstance(row, dict): continue
                sym = row.get('symbol') or row.get('name')
                if not sym: continue
                bid, ask = float(row.get('bid',0)), float(row.get('ask',0))
                if bid <= 0 or ask <= 0: continue
                mid = (bid+ask)/2
                hist = engine['ticks'][sym]
                hist.append(mid)
                if len(hist) < 22: continue
                spread = ask-bid
                max_spread = float(settings.get('max_spread',5.0))
                # spread guard in raw price units is deliberately conservative; user must tune after checking symbol digits.
                prev_fast = statistics.mean(list(hist)[-10:-1]); prev_slow = statistics.mean(list(hist)[-22:-1])
                fast = statistics.mean(list(hist)[-9:]); slow = statistics.mean(list(hist)[-21:])
                signal = 'buy' if prev_fast <= prev_slow and fast > slow else 'sell' if prev_fast >= prev_slow and fast < slow else None
                if not signal or spread > max_spread: continue
                pos = await bridge('/positions', {"symbol": sym})
                plist = pos.get('positions', pos.get('data', [])) if isinstance(pos,dict) else []
                if isinstance(plist,dict): plist = list(plist.values())
                existing = [p for p in plist if isinstance(p,dict) and p.get('strategy_tag') == STRATEGY_TAG]
                if existing: continue
                # Enforce a hard cap of five strategy-managed open positions across all configured symbols.
                all_pos = await bridge('/positions', {})
                all_rows = all_pos.get('positions', all_pos.get('data', [])) if isinstance(all_pos, dict) else []
                if isinstance(all_rows, dict): all_rows = list(all_rows.values())
                managed = [p for p in all_rows if isinstance(p, dict) and p.get('strategy_tag') == STRATEGY_TAG]
                if len(managed) >= int(settings.get('max_open_trades', 5)): continue
                order = await bridge('/', {"symbol":sym,"action":signal,"quantity":settings.get('quantity',0.01),"order_type":"MARKET","stop_loss":settings.get('stop_loss',30),"take_profit":settings.get('take_profit',60),"tpsl_mode":"pips","strategy_tag":STRATEGY_TAG})
                engine['last_signal'] = f"{signal.upper()} {sym}: {order}"
        except Exception as e:
            engine['last_error'] = str(e)

